#include<stdlib.h>
#include<stdio.h>
int main()
{
    int x = 0;
    if(x == 0) {
        printf("X is zero"); 
    }
    return 0;
}
